#!/usr/bin/env python3
"""Evaluate a semantic-segmentation checkpoint on the validation/test split."""

import argparse
import json
from contextlib import nullcontext
from pathlib import Path

import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from dataset.semantic_segmentation import (
    SemanticSegmentationDataset,
    SemanticValidTransform,
)
from model import RVMForSemanticSegmentation
from semantic_utils import (
    DEFAULT_CLASS_NAMES,
    ConfusionMatrix,
    format_metrics,
    parse_class_names,
    parse_class_weights,
    semantic_loss,
    torch_load,
)


def parse_args():
    parser = argparse.ArgumentParser(
        description=(
            "Load best_miou.pth (or another checkpoint) and compute semantic "
            "segmentation metrics without restoring training state."
        )
    )
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--images", default="images/test")
    parser.add_argument("--annotations", default="annotations/test")
    parser.add_argument(
        "--class-names",
        default=None,
        help=(
            "Optional comma-separated class names. By default, use the class "
            "mapping saved in the checkpoint."
        ),
    )
    parser.add_argument(
        "--input-size",
        type=int,
        default=None,
        help="By default, use the input size saved in the checkpoint.",
    )
    parser.add_argument("--ignore-index", type=int, default=255)
    parser.add_argument(
        "--resize-mode",
        choices=["letterbox", "stretch"],
        default="letterbox",
        help=(
            "letterbox preserves aspect ratio and ignores padded GT pixels; "
            "stretch reproduces the old direct 512x512 resize."
        ),
    )
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument(
        "--class-weights",
        default=None,
        help=(
            "Optional comma-separated weights used only when recomputing loss. "
            "IoU/Dice/accuracy are unaffected."
        ),
    )
    parser.add_argument(
        "--device",
        default="auto",
        help="auto, cpu, cuda, or cuda:N (default: auto).",
    )
    amp_group = parser.add_mutually_exclusive_group()
    amp_group.add_argument("--amp", dest="amp", action="store_true")
    amp_group.add_argument("--no-amp", dest="amp", action="store_false")
    parser.set_defaults(amp=True)
    parser.add_argument(
        "--output-json",
        type=Path,
        default=None,
        help=(
            "Result path. Default: <checkpoint_dir>/"
            "<checkpoint_stem>_<resize_mode>_test_results.json"
        ),
    )
    return parser.parse_args()


def resolve_device(value):
    if value == "auto":
        return torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    device = torch.device(value)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested, but torch.cuda.is_available() is False.")
    return device


def checkpoint_arg(checkpoint, name, default):
    saved_args = checkpoint.get("args", {})
    if not isinstance(saved_args, dict):
        return default
    value = saved_args.get(name, default)
    return default if value is None else value


def amp_context(enabled):
    if enabled:
        return torch.cuda.amp.autocast(enabled=True)
    return nullcontext()


@torch.inference_mode()
def evaluate(
    model,
    loader,
    device,
    class_names,
    class_weights,
    ignore_index,
    ce_weight,
    dice_weight,
    use_amp,
):
    model.eval()
    confusion = ConfusionMatrix(len(class_names), device=device)
    loss_sums = {
        "loss": 0.0,
        "cross_entropy_loss": 0.0,
        "dice_loss": 0.0,
    }
    sample_count = 0

    for images, masks in tqdm(loader, desc="Test", dynamic_ncols=True):
        images = images.to(device, non_blocking=True)
        masks = masks.to(device, non_blocking=True)

        with amp_context(use_amp):
            logits = model(images)[0]
            losses = semantic_loss(
                logits,
                masks,
                num_classes=len(class_names),
                class_weights=class_weights,
                ignore_index=ignore_index,
                ce_weight=ce_weight,
                dice_weight=dice_weight,
            )

        predictions = logits.argmax(dim=1)
        confusion.update(masks, predictions, ignore_index=ignore_index)

        batch_size = images.shape[0]
        loss_sums["loss"] += losses["total"].item() * batch_size
        loss_sums["cross_entropy_loss"] += losses["cross_entropy"].item() * batch_size
        loss_sums["dice_loss"] += losses["dice"].item() * batch_size
        sample_count += batch_size

    metrics = confusion.compute(class_names)
    for name, total in loss_sums.items():
        metrics[name] = total / max(sample_count, 1)
    metrics["num_images"] = sample_count
    metrics["confusion_matrix"] = confusion.matrix.to(torch.int64).cpu().tolist()
    return metrics


def main():
    args = parse_args()
    device = resolve_device(args.device)
    checkpoint_path = args.checkpoint.expanduser().resolve()
    data_root = args.data_root.expanduser().resolve()
    checkpoint = torch_load(checkpoint_path, map_location="cpu")

    saved_class_names = checkpoint.get("class_names", DEFAULT_CLASS_NAMES)
    class_names = (
        parse_class_names(args.class_names)
        if args.class_names is not None
        else list(saved_class_names)
    )
    if list(saved_class_names) != class_names:
        raise ValueError(
            f"Checkpoint classes are {saved_class_names}, but requested classes "
            f"are {class_names}. The index order must match exactly."
        )

    num_classes = int(checkpoint.get("num_classes", len(class_names)))
    if num_classes != len(class_names):
        raise ValueError(
            f"Checkpoint num_classes={num_classes}, but class_names has "
            f"{len(class_names)} entries."
        )

    variant = checkpoint.get("variant", "mobilenetv3")
    input_size = (
        args.input_size
        if args.input_size is not None
        else int(checkpoint.get("input_size", 512))
    )
    ce_weight = float(checkpoint_arg(checkpoint, "ce_weight", 1.0))
    dice_weight = float(checkpoint_arg(checkpoint, "dice_weight", 1.0))
    saved_class_weights = checkpoint_arg(checkpoint, "class_weights", None)
    class_weights_value = (
        args.class_weights
        if args.class_weights is not None
        else saved_class_weights
    )
    class_weights = parse_class_weights(class_weights_value, num_classes)
    if class_weights is not None:
        class_weights = class_weights.to(device)

    dataset = SemanticSegmentationDataset(
        data_root / args.images,
        data_root / args.annotations,
        num_classes=num_classes,
        ignore_index=args.ignore_index,
        transform=SemanticValidTransform(
            input_size,
            resize_mode=args.resize_mode,
            ignore_index=args.ignore_index,
        ),
    )
    loader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.workers,
        pin_memory=device.type == "cuda",
        persistent_workers=args.workers > 0,
        drop_last=False,
    )

    model = RVMForSemanticSegmentation(
        variant=variant,
        num_classes=num_classes,
        pretrained_backbone=False,
    )
    model.load_state_dict(checkpoint["model"], strict=True)
    model.to(device)

    print(f"Checkpoint: {checkpoint_path}")
    print(f"Saved epoch: {checkpoint.get('epoch', 'unknown')}")
    print(f"Saved best mIoU: {checkpoint.get('best_miou', 'unknown')}")
    print(f"Classes: {dict(enumerate(class_names))}")
    print(f"Data: {data_root / args.images}")
    print(f"Input size: {input_size}x{input_size}; device: {device}")
    print(f"Resize mode: {args.resize_mode}")

    metrics = evaluate(
        model=model,
        loader=loader,
        device=device,
        class_names=class_names,
        class_weights=class_weights,
        ignore_index=args.ignore_index,
        ce_weight=ce_weight,
        dice_weight=dice_weight,
        use_amp=args.amp and device.type == "cuda",
    )

    result = {
        "checkpoint": str(checkpoint_path),
        "checkpoint_epoch": checkpoint.get("epoch"),
        "checkpoint_best_miou": checkpoint.get("best_miou"),
        "data_root": str(data_root),
        "images": args.images,
        "annotations": args.annotations,
        "input_size": input_size,
        "resize_mode": args.resize_mode,
        "class_names": class_names,
        **metrics,
    }

    output_json = (
        args.output_json.expanduser().resolve()
        if args.output_json is not None
        else checkpoint_path.parent
        / f"{checkpoint_path.stem}_{args.resize_mode}_test_results.json"
    )
    output_json.parent.mkdir(parents=True, exist_ok=True)
    with output_json.open("w", encoding="utf-8") as file:
        json.dump(result, file, ensure_ascii=False, indent=2)

    print(format_metrics(metrics))
    print(f"Confusion matrix (rows=GT, columns=prediction):")
    print(torch.tensor(metrics["confusion_matrix"], dtype=torch.int64))
    print(f"Saved results: {output_json}")


if __name__ == "__main__":
    main()
