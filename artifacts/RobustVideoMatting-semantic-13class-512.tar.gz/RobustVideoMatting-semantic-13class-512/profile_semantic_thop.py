#!/usr/bin/env python3
"""
Profile the 13-class RVM semantic-segmentation model with THOP.

THOP reports MACs. This script also prints 2 * MACs as FLOPs under the
convention that one multiplication and one addition are two operations.
"""

import argparse
import json
from pathlib import Path

import torch
from torch import nn

try:
    from thop import clever_format, profile
except ImportError as exc:
    raise SystemExit(
        "THOP is not installed. Run: pip install thop"
    ) from exc

from model import RVMForSemanticSegmentation
from semantic_utils import DEFAULT_CLASS_NAMES, torch_load


class LogitsOnly(nn.Module):
    """Make THOP profile only the model forward used for semantic inference."""

    def __init__(self, model: nn.Module, downsample_ratio: float):
        super().__init__()
        self.model = model
        self.downsample_ratio = downsample_ratio

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        return self.model(
            image,
            downsample_ratio=self.downsample_ratio,
        )[0]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Measure RVM semantic-segmentation parameters and MACs with THOP."
    )
    parser.add_argument(
        "--checkpoint",
        type=Path,
        help=(
            "Optional semantic checkpoint such as best_miou.pth. When provided, "
            "variant, class count and input size are read from the checkpoint."
        ),
    )
    parser.add_argument(
        "--variant",
        choices=("mobilenetv3", "resnet50"),
        default="mobilenetv3",
        help="Used when --checkpoint is not provided.",
    )
    parser.add_argument(
        "--num-classes",
        type=int,
        default=13,
        help="Used when --checkpoint is not provided.",
    )
    parser.add_argument(
        "--height",
        type=int,
        default=None,
        help="Input height. Defaults to checkpoint input_size or 512.",
    )
    parser.add_argument(
        "--width",
        type=int,
        default=None,
        help="Input width. Defaults to checkpoint input_size or 512.",
    )
    parser.add_argument(
        "--downsample-ratio",
        type=float,
        default=1.0,
        help="RVM internal downsample ratio. Training/inference default is 1.0.",
    )
    parser.add_argument(
        "--device",
        default="cpu",
        help="Profiling device, for example cpu, cuda, or cuda:0.",
    )
    parser.add_argument(
        "--output-json",
        type=Path,
        help="Optional path for saving the numeric results.",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Print THOP layer registration messages.",
    )
    return parser.parse_args()


def load_model_config(args: argparse.Namespace):
    checkpoint = None
    variant = args.variant
    num_classes = args.num_classes
    checkpoint_input_size = 512
    class_names = DEFAULT_CLASS_NAMES[:num_classes]

    if args.checkpoint is not None:
        checkpoint = torch_load(args.checkpoint, map_location="cpu")
        variant = checkpoint.get("variant", variant)
        checkpoint_input_size = int(checkpoint.get("input_size", 512))
        class_names = checkpoint.get("class_names", DEFAULT_CLASS_NAMES)
        num_classes = len(class_names)

    height = args.height if args.height is not None else checkpoint_input_size
    width = args.width if args.width is not None else checkpoint_input_size

    if height <= 0 or width <= 0:
        raise ValueError("Input height and width must be positive.")
    if num_classes < 2:
        raise ValueError("num_classes must be at least 2.")
    if not 0 < args.downsample_ratio <= 1:
        raise ValueError("--downsample-ratio must be in (0, 1].")

    model = RVMForSemanticSegmentation(
        variant=variant,
        num_classes=num_classes,
        pretrained_backbone=False,
    )
    if checkpoint is not None:
        if "model" not in checkpoint:
            raise KeyError(
                f"{args.checkpoint} does not contain the expected 'model' state dict."
            )
        model.load_state_dict(checkpoint["model"], strict=True)

    return model, variant, class_names, height, width, checkpoint


def count_parameters(module: nn.Module) -> int:
    return sum(parameter.numel() for parameter in module.parameters())


def main() -> None:
    args = parse_args()
    device = torch.device(args.device)
    model, variant, class_names, height, width, checkpoint = load_model_config(args)
    model = model.eval().to(device)
    wrapped_model = LogitsOnly(model, args.downsample_ratio).eval()
    dummy = torch.randn(1, 3, height, width, device=device)

    with torch.inference_mode():
        macs, thop_parameters = profile(
            wrapped_model,
            inputs=(dummy,),
            verbose=args.verbose,
        )

    total_parameters = count_parameters(model)
    trainable_parameters = sum(
        parameter.numel()
        for parameter in model.parameters()
        if parameter.requires_grad
    )
    if int(thop_parameters) != total_parameters:
        print(
            "Warning: THOP parameter count differs from PyTorch count: "
            f"THOP={int(thop_parameters)}, PyTorch={total_parameters}"
        )

    flops_mul_add_as_two = 2.0 * macs
    pretty_macs, pretty_parameters = clever_format(
        [macs, total_parameters],
        "%.4f",
    )
    pretty_flops = clever_format([flops_mul_add_as_two], "%.4f")[0]

    print("\n===== RVM Semantic Segmentation Complexity =====")
    print(f"Variant                 : {variant}")
    print(f"Classes                 : {len(class_names)} {list(class_names)}")
    print(f"Input                   : 1 x 3 x {height} x {width}")
    print(f"Downsample ratio        : {args.downsample_ratio}")
    if checkpoint is not None:
        print(f"Checkpoint              : {args.checkpoint}")
        print(f"Checkpoint epoch        : {checkpoint.get('epoch', 'unknown')}")
    print(f"Parameters              : {total_parameters:,} ({pretty_parameters})")
    print(f"Trainable parameters    : {trainable_parameters:,}")
    print(f"THOP MACs               : {int(macs):,} ({pretty_macs})")
    print(
        "FLOPs (2 x MACs)        : "
        f"{int(flops_mul_add_as_two):,} ({pretty_flops})"
    )
    print("\nParameter breakdown:")
    print(f"  backbone              : {count_parameters(model.backbone):,}")
    print(f"  LR-ASPP               : {count_parameters(model.aspp):,}")
    print(f"  recurrent decoder     : {count_parameters(model.decoder):,}")
    print(
        f"  {len(class_names)}-class head"
        f"{' ' * max(1, 16 - len(str(len(class_names))))}: "
        f"{count_parameters(model.project_seg):,}"
    )
    print(
        "\nNote: THOP's primary result is MACs. Some papers/tools label MACs "
        "as FLOPs; others use FLOPs = 2 x MACs. Use the same convention "
        "when comparing with SCTNet."
    )

    if args.output_json is not None:
        result = {
            "variant": variant,
            "class_names": list(class_names),
            "num_classes": len(class_names),
            "input_shape": [1, 3, height, width],
            "downsample_ratio": args.downsample_ratio,
            "parameters": total_parameters,
            "trainable_parameters": trainable_parameters,
            "thop_macs": int(macs),
            "flops_mul_add_as_two": int(flops_mul_add_as_two),
            "parameter_breakdown": {
                "backbone": count_parameters(model.backbone),
                "lraspp": count_parameters(model.aspp),
                "recurrent_decoder": count_parameters(model.decoder),
                "semantic_head": count_parameters(model.project_seg),
            },
            "checkpoint": str(args.checkpoint) if args.checkpoint else None,
            "checkpoint_epoch": (
                checkpoint.get("epoch") if checkpoint is not None else None
            ),
        }
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(
            json.dumps(result, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        print(f"Saved JSON             : {args.output_json}")


if __name__ == "__main__":
    main()
