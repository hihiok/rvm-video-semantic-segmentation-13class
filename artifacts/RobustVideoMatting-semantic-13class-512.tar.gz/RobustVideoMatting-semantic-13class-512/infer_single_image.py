#!/usr/bin/env python3
"""Run the 12-class RVM semantic-segmentation model on one image without GT."""

import argparse
import json
from contextlib import nullcontext
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageOps
from torchvision.transforms import functional as TF

from inference_semantic import (
    add_class_labels,
    prepare_input,
    restore_prediction,
)
from model import RVMForSemanticSegmentation
from semantic_utils import DEFAULT_CLASS_NAMES, colorize_mask, torch_load


def parse_args():
    parser = argparse.ArgumentParser(
        description=(
            "Infer one arbitrary image with a trained RVM semantic-segmentation "
            "checkpoint. No annotation/GT mask is required."
        )
    )
    parser.add_argument("--image", type=Path, required=True, help="Input image path.")
    parser.add_argument(
        "--checkpoint",
        type=Path,
        required=True,
        help="Path to best_miou.pth or another semantic checkpoint.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("inference_output"),
        help="Directory for the index mask, color mask, overlay and JSON.",
    )
    parser.add_argument(
        "--device",
        default="auto",
        help="auto, cpu, cuda, or cuda:N (default: auto).",
    )
    parser.add_argument(
        "--input-size",
        type=int,
        default=None,
        help="Normally omitted so the value saved in the checkpoint is used.",
    )
    parser.add_argument(
        "--overlay-alpha",
        type=float,
        default=0.5,
        help="Color-mask opacity in the overlay, from 0 to 1.",
    )
    parser.add_argument(
        "--resize-mode",
        choices=["letterbox", "stretch"],
        default="letterbox",
        help="letterbox preserves aspect ratio and is the default.",
    )
    parser.add_argument(
        "--no-amp",
        action="store_true",
        help="Disable CUDA mixed-precision inference.",
    )
    return parser.parse_args()


def resolve_device(value):
    if value == "auto":
        return torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    device = torch.device(value)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested, but torch.cuda.is_available() is False.")
    return device


def load_model(checkpoint_path, device, input_size_override=None):
    checkpoint = torch_load(checkpoint_path, map_location="cpu")
    if not isinstance(checkpoint, dict) or "model" not in checkpoint:
        raise ValueError(
            "Expected a semantic training checkpoint containing the key 'model'. "
            "Please use best_miou.pth or last.pth produced by train_semantic.py."
        )

    class_names = list(checkpoint.get("class_names", DEFAULT_CLASS_NAMES))
    num_classes = int(checkpoint.get("num_classes", len(class_names)))
    if num_classes != len(class_names):
        raise ValueError(
            f"Checkpoint num_classes={num_classes}, but class_names={class_names}."
        )

    variant = checkpoint.get("variant", "mobilenetv3")
    checkpoint_input_size = int(checkpoint.get("input_size", 512))
    input_size = (
        int(input_size_override)
        if input_size_override is not None
        else checkpoint_input_size
    )
    if input_size <= 0:
        raise ValueError("--input-size must be positive.")

    model = RVMForSemanticSegmentation(
        variant=variant,
        num_classes=num_classes,
        pretrained_backbone=False,
    )
    model.load_state_dict(checkpoint["model"], strict=True)
    model.eval().to(device)
    return model, checkpoint, class_names, input_size


def amp_context(device, enabled):
    if device.type == "cuda" and enabled:
        return torch.cuda.amp.autocast(enabled=True)
    return nullcontext()


@torch.inference_mode()
def predict(model, image, input_size, device, use_amp, resize_mode):
    resized, letterbox_info = prepare_input(image, input_size, resize_mode)
    tensor = TF.to_tensor(resized).unsqueeze(0).to(device)

    with amp_context(device, use_amp):
        logits = model(tensor)[0]
    prediction_512 = logits.argmax(dim=1)[0].to(torch.uint8).cpu().numpy()

    return restore_prediction(
        prediction_512,
        image.size,
        letterbox_info,
    )


def main():
    args = parse_args()
    if not 0.0 <= args.overlay_alpha <= 1.0:
        raise ValueError("--overlay-alpha must be between 0 and 1.")

    image_path = args.image.expanduser().resolve()
    checkpoint_path = args.checkpoint.expanduser().resolve()
    output_dir = args.output_dir.expanduser().resolve()
    if not image_path.is_file():
        raise FileNotFoundError(f"Input image does not exist: {image_path}")
    if not checkpoint_path.is_file():
        raise FileNotFoundError(f"Checkpoint does not exist: {checkpoint_path}")

    device = resolve_device(args.device)
    model, checkpoint, class_names, input_size = load_model(
        checkpoint_path,
        device,
        input_size_override=args.input_size,
    )

    with Image.open(image_path) as image_file:
        # Apply camera/phone EXIF orientation before inference and output.
        image = ImageOps.exif_transpose(image_file).convert("RGB")

    prediction = predict(
        model,
        image,
        input_size=input_size,
        device=device,
        use_amp=not args.no_amp,
        resize_mode=args.resize_mode,
    )
    color = colorize_mask(prediction)
    original = np.asarray(image, dtype=np.uint8)
    overlay = (
        original.astype(np.float32) * (1.0 - args.overlay_alpha)
        + color.astype(np.float32) * args.overlay_alpha
    ).clip(0, 255).astype(np.uint8)
    overlay = add_class_labels(overlay, prediction, class_names)

    output_dir.mkdir(parents=True, exist_ok=True)
    stem = image_path.stem
    mask_path = output_dir / f"{stem}_mask.png"
    color_path = output_dir / f"{stem}_color.png"
    overlay_path = output_dir / f"{stem}_overlay.jpg"
    json_path = output_dir / f"{stem}_result.json"

    Image.fromarray(prediction, mode="L").save(mask_path)
    Image.fromarray(color, mode="RGB").save(color_path)
    Image.fromarray(overlay, mode="RGB").save(overlay_path, quality=95)

    total_pixels = int(prediction.size)
    pixel_counts = {
        name: int(np.count_nonzero(prediction == index))
        for index, name in enumerate(class_names)
    }
    result = {
        "image": str(image_path),
        "checkpoint": str(checkpoint_path),
        "checkpoint_epoch": checkpoint.get("epoch"),
        "checkpoint_best_miou": checkpoint.get("best_miou"),
        "device": str(device),
        "network_input_size": [input_size, input_size],
        "resize_mode": args.resize_mode,
        "original_size": [image.width, image.height],
        "class_mapping": {
            str(index): name for index, name in enumerate(class_names)
        },
        "pixel_counts": pixel_counts,
        "pixel_ratios": {
            name: count / max(total_pixels, 1)
            for name, count in pixel_counts.items()
        },
        "outputs": {
            "index_mask": str(mask_path),
            "color_mask": str(color_path),
            "overlay": str(overlay_path),
        },
    }
    with json_path.open("w", encoding="utf-8") as file:
        json.dump(result, file, ensure_ascii=False, indent=2)

    print(f"Input: {image_path}")
    print(f"Original size: {image.width}x{image.height}")
    print(f"Network input: {input_size}x{input_size}")
    print(f"Resize mode: {args.resize_mode}")
    print(f"Checkpoint epoch: {checkpoint.get('epoch', 'unknown')}")
    print(f"Class mapping: {result['class_mapping']}")
    print(f"Index mask: {mask_path}")
    print(f"Color mask: {color_path}")
    print(f"Overlay: {overlay_path}")
    print(f"Details: {json_path}")


if __name__ == "__main__":
    main()
