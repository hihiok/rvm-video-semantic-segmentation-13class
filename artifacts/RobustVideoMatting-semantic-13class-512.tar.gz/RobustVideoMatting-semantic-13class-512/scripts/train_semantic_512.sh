#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "$SCRIPT_DIR/.." && pwd)"
cd "$REPO_ROOT"

DATA_ROOT="${1:-/data/pub1/y00841348/dataset/AI-Seg-12class/cocostuff164k+ade20k_13class}"
OUTPUT_DIR="${2:-output/rvm_semantic_13class_512}"
TRAIN_SPLIT="${3:-train}"
VAL_SPLIT="${4:-val}"

python train_semantic.py \
  --data-root "$DATA_ROOT" \
  --variant mobilenetv3 \
  --train-images "images/$TRAIN_SPLIT" \
  --train-annotations "annotations/$TRAIN_SPLIT" \
  --val-images "images/$VAL_SPLIT" \
  --val-annotations "annotations/$VAL_SPLIT" \
  --class-names background,sky,person,plant,building,flower,food,water,desert,ice_or_snow,text,ball,mountain \
  --input-size 512 \
  --epochs 100 \
  --batch-size 8 \
  --workers 8 \
  --learning-rate 1e-4 \
  --backbone-learning-rate 1e-5 \
  --ce-weight 1.0 \
  --dice-weight 1.0 \
  --val-resize-mode letterbox \
  --output-dir "$OUTPUT_DIR"
