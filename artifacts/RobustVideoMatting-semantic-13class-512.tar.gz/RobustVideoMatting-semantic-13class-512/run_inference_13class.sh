#!/usr/bin/env bash
set -euo pipefail

CONDA_SH="${CONDA_SH:-/home/z00919662/anaconda3/etc/profile.d/conda.sh}"
CONDA_ENV_NAME="${CONDA_ENV_NAME:-ultraface}"
REPO_ROOT="${REPO_ROOT:-/data/pub1/z00919662/segmentation/RobustVideoMatting-semantic-13class-512}"
CHECKPOINT="${CHECKPOINT:-$REPO_ROOT/output/rvm_semantic_13class_512_2gpu/best_miou.pth}"

# 也可以将输入、输出作为第 1、2 个参数传入。
INPUT_PATH="${1:-${INPUT_PATH:-/data/pub1/z00919662/dataset/chenshuo_face_frames}}"
OUTPUT_DIR="${2:-${OUTPUT_DIR:-$REPO_ROOT/inference_output_13class}}"
RESIZE_MODE="${RESIZE_MODE:-letterbox}"

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export PYTHONUNBUFFERED=1

[[ -f "$CONDA_SH" ]] || { echo "Conda initialization script not found: $CONDA_SH" >&2; exit 1; }
[[ -d "$REPO_ROOT" ]] || { echo "13-class repository not found: $REPO_ROOT" >&2; exit 1; }
[[ -f "$CHECKPOINT" ]] || { echo "Checkpoint not found: $CHECKPOINT" >&2; exit 1; }
[[ -e "$INPUT_PATH" ]] || { echo "Inference input not found: $INPUT_PATH" >&2; exit 1; }

source "$CONDA_SH"
conda activate "$CONDA_ENV_NAME"
cd "$REPO_ROOT"
mkdir -p "$OUTPUT_DIR"

python inference_semantic.py \
  --checkpoint "$CHECKPOINT" \
  --input "$INPUT_PATH" \
  --output-dir "$OUTPUT_DIR" \
  --resize-mode "$RESIZE_MODE"

# 默认每张图片独立推理，不继承上一张图片的 ConvGRU 状态。
# 当前模型使用无关单帧训练，通常不要添加 --keep-recurrence。
#
# 示例：
# bash run_inference_13class.sh /path/to/images /path/to/output
