#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "$SCRIPT_DIR/.." && pwd)"
cd "$REPO_ROOT"

DATA_ROOT="${1:-/data/pub1/y00841348/dataset/AI-Seg-12class/cocostuff164k+ade20k_13class}"
OUTPUT_DIR="${2:-output/rvm_semantic_13class_512}"
TRAIN_SPLIT="${3:-train}"
VAL_SPLIT="${4:-val}"
INIT_CHECKPOINT="${5:-}"
INIT_ARGS=()
if [[ -n "$INIT_CHECKPOINT" ]]; then
  INIT_ARGS=(--rvm-checkpoint "$INIT_CHECKPOINT")
fi

if [[ "$(python -c 'import torch; print(torch.cuda.device_count())')" != "2" ]]; then
  echo "Expected exactly 2 visible GPUs. Set CUDA_VISIBLE_DEVICES before running."
  exit 2
fi

python -m torch.distributed.run \
  --standalone \
  --nproc_per_node=2 \
  train_semantic.py \
  --data-root "$DATA_ROOT" \
  --train-images "images/$TRAIN_SPLIT" \
  --train-annotations "annotations/$TRAIN_SPLIT" \
  --val-images "images/$VAL_SPLIT" \
  --val-annotations "annotations/$VAL_SPLIT" \
  --variant mobilenetv3 \
  --class-names background,sky,person,plant,building,flower,food,water,desert,ice_or_snow,text,ball,mountain \
  --input-size 512 \
  --epochs 100 \
  --batch-size 8 \
  --workers 8 \
  --learning-rate 1e-4 \
  --backbone-learning-rate 1e-5 \
  --weight-decay 1e-4 \
  --ce-weight 1.0 \
  --dice-weight 1.0 \
  --train-scale-min 0.5 \
  --train-scale-max 2.0 \
  --val-resize-mode letterbox \
  --sync-bn \
  --amp \
  "${INIT_ARGS[@]}" \
  --output-dir "$OUTPUT_DIR"
