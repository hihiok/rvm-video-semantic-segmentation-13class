#!/usr/bin/env python3
import argparse
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont
from torchvision.transforms import functional as F
from tqdm import tqdm

from dataset.semantic_segmentation import IMAGE_EXTENSIONS, letterbox_geometry
from model import RVMForSemanticSegmentation
from semantic_utils import (
    DEFAULT_CLASS_NAMES,
    DEFAULT_PALETTE,
    colorize_mask,
    torch_load,
)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run multi-class RVM semantic segmentation on images."
    )
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--overlay-alpha", type=float, default=0.5)
    parser.add_argument(
        "--resize-mode",
        choices=["letterbox", "stretch"],
        default="letterbox",
        help="letterbox preserves aspect ratio; stretch directly resizes to a square.",
    )
    parser.add_argument(
        "--keep-recurrence",
        action="store_true",
        help="Carry RVM states across sorted input images (for extracted video frames).",
    )
    return parser.parse_args()


def find_images(path):
    if path.is_file():
        return [path]
    return sorted(
        item for item in path.rglob("*")
        if item.is_file() and item.suffix.lower() in IMAGE_EXTENSIONS
    )


def load_font(size):
    try:
        return ImageFont.truetype("DejaVuSans-Bold.ttf", size=size)
    except OSError:
        return ImageFont.load_default()


def text_size(draw, text, font):
    if hasattr(draw, "textbbox"):
        left, top, right, bottom = draw.textbbox((0, 0), text, font=font)
        return right - left, bottom - top
    return draw.textsize(text, font=font)


def class_label_position(class_mask):
    """Return a pixel near the spatial center that belongs to the class."""
    rows, columns = np.nonzero(class_mask)
    if len(rows) == 0:
        return None
    center_row = rows.mean()
    center_column = columns.mean()
    stride = max(1, len(rows) // 10000)
    sampled_rows = rows[::stride]
    sampled_columns = columns[::stride]
    nearest = np.argmin(
        (sampled_rows - center_row) ** 2
        + (sampled_columns - center_column) ** 2
    )
    return int(sampled_columns[nearest]), int(sampled_rows[nearest])


def add_class_labels(overlay, prediction, class_names, palette=DEFAULT_PALETTE):
    """Add in-region class names and a color legend to an RGB overlay."""
    canvas = Image.fromarray(overlay, mode="RGB").convert("RGBA")
    layer = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    width, height = canvas.size

    font_size = max(11, min(28, int(round(min(width, height) * 0.032))))
    font = load_font(font_size)
    padding = max(4, font_size // 3)
    swatch_size = max(10, font_size)
    line_gap = max(3, font_size // 4)

    present_indices = [
        int(index)
        for index in np.unique(prediction)
        if 0 <= int(index) < min(len(class_names), len(palette))
    ]

    # Put each class name directly on a representative pixel of its region.
    min_region_pixels = max(1, int(prediction.size * 0.0005))
    for class_index in present_indices:
        class_mask = prediction == class_index
        if int(class_mask.sum()) < min_region_pixels:
            continue
        position = class_label_position(class_mask)
        if position is None:
            continue
        label = str(class_names[class_index])
        label_width, label_height = text_size(draw, label, font)
        center_x, center_y = position
        left = max(
            0,
            min(
                width - label_width - 2 * padding,
                center_x - label_width // 2 - padding,
            ),
        )
        top = max(
            0,
            min(
                height - label_height - 2 * padding,
                center_y - label_height // 2 - padding,
            ),
        )
        right = left + label_width + 2 * padding
        bottom = top + label_height + 2 * padding
        draw.rounded_rectangle(
            (left, top, right, bottom),
            radius=padding,
            fill=(0, 0, 0, 190),
            outline=tuple(palette[class_index]) + (255,),
            width=max(1, font_size // 8),
        )
        draw.text(
            (left + padding, top + padding),
            label,
            font=font,
            fill=(255, 255, 255, 255),
        )

    # Add a compact legend containing only classes predicted in this image.
    if present_indices:
        legend_rows = []
        for class_index in present_indices:
            label = str(class_names[class_index])
            label_width, label_height = text_size(draw, label, font)
            legend_rows.append((class_index, label, label_width, label_height))
        legend_width = max(
            swatch_size + padding + row[2] for row in legend_rows
        ) + 2 * padding
        row_height = max(
            swatch_size, max(row[3] for row in legend_rows)
        )
        legend_height = (
            2 * padding
            + len(legend_rows) * row_height
            + max(0, len(legend_rows) - 1) * line_gap
        )
        draw.rounded_rectangle(
            (padding, padding, padding + legend_width, padding + legend_height),
            radius=padding,
            fill=(0, 0, 0, 180),
        )
        y = 2 * padding
        for class_index, label, _, label_height in legend_rows:
            draw.rectangle(
                (2 * padding, y, 2 * padding + swatch_size, y + swatch_size),
                fill=tuple(palette[class_index]) + (255,),
                outline=(255, 255, 255, 255),
                width=1,
            )
            draw.text(
                (
                    3 * padding + swatch_size,
                    y + (row_height - label_height) // 2,
                ),
                label,
                font=font,
                fill=(255, 255, 255, 255),
            )
            y += row_height + line_gap

    return np.asarray(Image.alpha_composite(canvas, layer).convert("RGB"))


def prepare_input(image, input_size, resize_mode):
    if resize_mode == "stretch":
        resized = F.resize(
            image,
            [input_size, input_size],
            interpolation=F.InterpolationMode.BILINEAR,
        )
        return resized, None

    resized_w, resized_h, padding = letterbox_geometry(
        image.width, image.height, input_size
    )
    resized = F.resize(
        image,
        [resized_h, resized_w],
        interpolation=F.InterpolationMode.BILINEAR,
    )
    resized = F.pad(resized, list(padding), fill=0)
    return resized, (resized_w, resized_h, padding)


def restore_prediction(prediction, original_size, letterbox_info):
    nearest = getattr(Image, "Resampling", Image).NEAREST
    prediction_image = Image.fromarray(prediction.astype(np.uint8), mode="L")
    if letterbox_info is not None:
        resized_w, resized_h, padding = letterbox_info
        pad_left, pad_top, _, _ = padding
        prediction_image = prediction_image.crop(
            (
                pad_left,
                pad_top,
                pad_left + resized_w,
                pad_top + resized_h,
            )
        )
    return np.asarray(
        prediction_image.resize(original_size, resample=nearest),
        dtype=np.uint8,
    )


def main():
    args = parse_args()
    if not 0 <= args.overlay_alpha <= 1:
        raise ValueError("--overlay-alpha must be between 0 and 1.")
    checkpoint = torch_load(args.checkpoint, map_location="cpu")
    class_names = checkpoint.get("class_names", DEFAULT_CLASS_NAMES)
    if len(class_names) != int(checkpoint.get("num_classes", len(class_names))):
        raise ValueError("Checkpoint class_names and num_classes do not agree.")
    if len(class_names) > len(DEFAULT_PALETTE):
        raise ValueError(
            f"Need at least {len(class_names)} palette colors, "
            f"but only {len(DEFAULT_PALETTE)} are configured."
        )
    variant = checkpoint.get("variant", "mobilenetv3")
    input_size = int(checkpoint.get("input_size", 512))
    model = RVMForSemanticSegmentation(
        variant=variant, num_classes=len(class_names)
    )
    model.load_state_dict(checkpoint["model"], strict=True)
    model.eval().to(args.device)

    images = find_images(args.input)
    if not images:
        raise RuntimeError(f"No supported images found: {args.input}")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rec = [None] * 4
    with torch.no_grad():
        for image_path in tqdm(images, desc="Inference"):
            with Image.open(image_path) as image_file:
                image = image_file.convert("RGB")
            original = np.asarray(image)
            resized, letterbox_info = prepare_input(
                image,
                input_size,
                args.resize_mode,
            )
            tensor = F.to_tensor(resized).unsqueeze(0).to(args.device)
            logits, *new_rec = model(tensor, *rec)
            if args.keep_recurrence:
                rec = new_rec
            prediction = logits.argmax(dim=1)[0].byte().cpu().numpy()
            prediction = restore_prediction(
                prediction,
                image.size,
                letterbox_info,
            )
            color = colorize_mask(prediction)
            overlay = (
                original.astype(np.float32) * (1 - args.overlay_alpha)
                + color.astype(np.float32) * args.overlay_alpha
            ).clip(0, 255).astype(np.uint8)
            overlay = add_class_labels(overlay, prediction, class_names)

            relative = image_path.name if args.input.is_file() else image_path.relative_to(args.input)
            stem = Path(relative).with_suffix("")
            target_parent = args.output_dir / stem.parent
            target_parent.mkdir(parents=True, exist_ok=True)
            Image.fromarray(prediction, mode="L").save(target_parent / f"{stem.name}_mask.png")
            Image.fromarray(color, mode="RGB").save(target_parent / f"{stem.name}_color.png")
            Image.fromarray(overlay, mode="RGB").save(target_parent / f"{stem.name}_overlay.jpg")

    print(f"Saved {len(images)} predictions to: {args.output_dir}")
    print(f"Class mapping: {dict(enumerate(class_names))}")
    print(f"Resize mode: {args.resize_mode}")


if __name__ == "__main__":
    main()
