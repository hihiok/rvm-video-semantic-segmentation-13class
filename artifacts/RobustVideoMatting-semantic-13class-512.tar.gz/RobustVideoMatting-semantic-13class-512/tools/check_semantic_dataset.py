#!/usr/bin/env python3
import argparse
import sys
from collections import Counter
from pathlib import Path

import numpy as np
from PIL import Image
from tqdm import tqdm

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dataset.semantic_segmentation import build_image_mask_pairs
from semantic_utils import DEFAULT_CLASS_NAMES, parse_class_names


def parse_args():
    parser = argparse.ArgumentParser(
        description="Validate image/mask pairing and class IDs before training."
    )
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument(
        "--splits",
        nargs="+",
        default=["train", "val", "test"],
        help="Split directory names under images/ and annotations/.",
    )
    parser.add_argument("--images-root", default="images")
    parser.add_argument("--annotations-root", default="annotations")
    parser.add_argument(
        "--class-names", default=",".join(DEFAULT_CLASS_NAMES)
    )
    parser.add_argument("--ignore-index", type=int, default=255)
    parser.add_argument("--max-masks", type=int, help="Optional quick-check limit.")
    return parser.parse_args()


def inspect_split(
    data_root,
    split,
    images_root,
    annotations_root,
    class_names,
    ignore_index,
    max_masks,
):
    image_dir = data_root / images_root / split
    mask_dir = data_root / annotations_root / split
    pairs = build_image_mask_pairs(image_dir, mask_dir)
    if max_masks is not None:
        pairs_to_scan = pairs[:max_masks]
    else:
        pairs_to_scan = pairs

    counts = Counter()
    modes = Counter()
    shapes_differ = 0
    background_only = 0
    image_counts = Counter()
    errors = []
    for image_path, mask_path in tqdm(pairs_to_scan, desc=f"Check {split}"):
        with Image.open(image_path) as image:
            image_size = image.size
        with Image.open(mask_path) as mask:
            modes[mask.mode] += 1
            mask_size = mask.size
            array = np.array(mask, copy=True)
        if image_size != mask_size:
            shapes_differ += 1
            errors.append(
                f"{image_path}: image size {image_size} != mask size {mask_size}"
            )
        if array.ndim != 2:
            errors.append(f"{mask_path}: expected 2D mask, got shape {array.shape}")
            continue
        unique, pixel_counts = np.unique(array, return_counts=True)
        counts.update(dict(zip(unique.tolist(), pixel_counts.tolist())))
        present = set(unique.tolist()) - {ignore_index}
        for class_id in present:
            image_counts[class_id] += 1
        if not (present - {0}):
            background_only += 1

    valid_ids = set(range(len(class_names))) | {ignore_index}
    unexpected = sorted(set(counts) - valid_ids)
    missing = [index for index in range(len(class_names)) if counts[index] == 0]

    print(f"\n[{split}]")
    print(f"pairs={len(pairs)}, scanned={len(pairs_to_scan)}, mask_modes={dict(modes)}")
    print(f"image/mask size mismatches={shapes_differ}")
    print(f"background-only images={background_only}")
    print("pixel counts:")
    for index, name in enumerate(class_names):
        print(
            f"  {index}={name}: pixels={counts[index]}, "
            f"images={image_counts[index]}"
        )
    if counts[ignore_index]:
        print(f"  {ignore_index}=ignore: {counts[ignore_index]}")
    if missing:
        print(
            "WARNING: classes absent from scanned masks: "
            + ", ".join(f"{index}={class_names[index]}" for index in missing)
        )
    if unexpected:
        errors.append(f"Unexpected class IDs: {unexpected}")
    return errors


def main():
    args = parse_args()
    class_names = parse_class_names(args.class_names)
    print(f"Expected mapping: {dict(enumerate(class_names))}")
    errors = []
    for split in args.splits:
        errors.extend(
            inspect_split(
                args.data_root,
                split,
                args.images_root,
                args.annotations_root,
                class_names,
                args.ignore_index,
                args.max_masks,
            )
        )
    if errors:
        print("\nERRORS:")
        for error in errors:
            print(f"  - {error}")
        raise SystemExit(1)
    print("\nDataset check passed.")


if __name__ == "__main__":
    main()
