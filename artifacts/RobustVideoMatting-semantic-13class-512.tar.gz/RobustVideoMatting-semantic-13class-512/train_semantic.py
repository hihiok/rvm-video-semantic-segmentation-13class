#!/usr/bin/env python3
import argparse
import json
import os
import time
from contextlib import nullcontext
from pathlib import Path

import torch
from torch import distributed as dist
from torch.nn.parallel import DistributedDataParallel
from torch.optim import AdamW
from torch.optim.lr_scheduler import LambdaLR
from torch.utils.data import DataLoader, Sampler
from torch.utils.data.distributed import DistributedSampler
from tqdm import tqdm

from dataset.semantic_segmentation import (
    SemanticSegmentationDataset,
    SemanticTrainTransform,
    SemanticValidTransform,
)
from model import RVMForSemanticSegmentation, load_compatible_weights
from semantic_utils import (
    DEFAULT_CLASS_NAMES,
    ConfusionMatrix,
    append_metrics_csv,
    atomic_torch_save,
    format_metrics,
    parse_class_names,
    parse_class_weights,
    seed_everything,
    seed_worker,
    semantic_loss,
    torch_load,
    unwrap_model,
)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Train RVM as a multi-class semantic segmentation network."
    )
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--train-images", default="images/train")
    parser.add_argument("--train-annotations", default="annotations/train")
    parser.add_argument("--val-images", default="images/val")
    parser.add_argument("--val-annotations", default="annotations/val")
    parser.add_argument(
        "--class-names", default=",".join(DEFAULT_CLASS_NAMES),
        help="Comma-separated names in exact class-index order.",
    )
    parser.add_argument("--ignore-index", type=int, default=255)
    parser.add_argument("--variant", choices=["mobilenetv3", "resnet50"], default="mobilenetv3")
    parser.add_argument("--input-size", type=int, default=512)
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--batch-size", type=int, default=8, help="Per-process batch size.")
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--backbone-learning-rate", type=float, default=1e-5)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--ce-weight", type=float, default=1.0)
    parser.add_argument("--dice-weight", type=float, default=1.0)
    parser.add_argument(
        "--class-weights",
        help="Optional comma-separated weights, one per class.",
    )
    parser.add_argument("--train-scale-min", type=float, default=0.5)
    parser.add_argument("--train-scale-max", type=float, default=2.0)
    parser.add_argument(
        "--val-resize-mode",
        choices=["letterbox", "stretch"],
        default="letterbox",
        help=(
            "Validation preprocessing. letterbox preserves aspect ratio and "
            "fills mask padding with ignore_index."
        ),
    )
    pretrained_group = parser.add_mutually_exclusive_group()
    pretrained_group.add_argument(
        "--pretrained-backbone", dest="pretrained_backbone", action="store_true"
    )
    pretrained_group.add_argument(
        "--no-pretrained-backbone", dest="pretrained_backbone", action="store_false"
    )
    parser.set_defaults(pretrained_backbone=True)
    checkpoint_group = parser.add_mutually_exclusive_group()
    checkpoint_group.add_argument(
        "--rvm-checkpoint",
        type=Path,
        help="Optional original RVM checkpoint; incompatible matting heads are skipped.",
    )
    checkpoint_group.add_argument(
        "--resume",
        type=Path,
        help="Resume a 13-class semantic training checkpoint.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("output/rvm_semantic_13class_512"),
    )
    parser.add_argument("--save-every", type=int, default=10)
    parser.add_argument("--print-every", type=int, default=20)
    parser.add_argument("--seed", type=int, default=1337)
    amp_group = parser.add_mutually_exclusive_group()
    amp_group.add_argument("--amp", dest="amp", action="store_true")
    amp_group.add_argument("--no-amp", dest="amp", action="store_false")
    parser.set_defaults(amp=True)
    parser.add_argument("--sync-bn", action="store_true")
    parser.add_argument("--evaluate-only", action="store_true")
    parser.add_argument("--device", default="auto", help="auto, cpu, cuda, or cuda:N")
    return parser.parse_args()


def distributed_info(args):
    world_size = int(os.environ.get("WORLD_SIZE", "1"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    distributed = world_size > 1
    if args.device == "auto":
        device = torch.device(f"cuda:{local_rank}" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)
    if distributed:
        if device.type == "cuda":
            torch.cuda.set_device(device)
        dist.init_process_group(backend="nccl" if device.type == "cuda" else "gloo")
    rank = dist.get_rank() if distributed else 0
    return distributed, rank, world_size, local_rank, device


class DistributedEvalSampler(Sampler):
    """Shard evaluation without padding or duplicating samples."""

    def __init__(self, dataset, rank, world_size):
        self.dataset = dataset
        self.rank = rank
        self.world_size = world_size

    def __iter__(self):
        return iter(range(self.rank, len(self.dataset), self.world_size))

    def __len__(self):
        remaining = len(self.dataset) - self.rank
        return max(0, (remaining + self.world_size - 1) // self.world_size)


def make_dataloaders(args, num_classes, distributed, rank, world_size):
    train_dataset = SemanticSegmentationDataset(
        args.data_root / args.train_images,
        args.data_root / args.train_annotations,
        num_classes=num_classes,
        ignore_index=args.ignore_index,
        transform=SemanticTrainTransform(
            args.input_size,
            scale_range=(args.train_scale_min, args.train_scale_max),
            ignore_index=args.ignore_index,
        ),
    )
    val_dataset = SemanticSegmentationDataset(
        args.data_root / args.val_images,
        args.data_root / args.val_annotations,
        num_classes=num_classes,
        ignore_index=args.ignore_index,
        transform=SemanticValidTransform(
            args.input_size,
            resize_mode=args.val_resize_mode,
            ignore_index=args.ignore_index,
        ),
    )
    train_sampler = (
        DistributedSampler(
            train_dataset, num_replicas=world_size, rank=rank, shuffle=True
        )
        if distributed else None
    )
    val_sampler = (
        DistributedEvalSampler(val_dataset, rank=rank, world_size=world_size)
        if distributed else None
    )
    common = dict(
        batch_size=args.batch_size,
        num_workers=args.workers,
        pin_memory=torch.cuda.is_available(),
        persistent_workers=args.workers > 0,
        worker_init_fn=seed_worker,
    )
    train_loader = DataLoader(
        train_dataset,
        shuffle=train_sampler is None,
        sampler=train_sampler,
        drop_last=True,
        **common,
    )
    val_loader = DataLoader(
        val_dataset,
        shuffle=False,
        sampler=val_sampler,
        drop_last=False,
        **common,
    )
    return train_loader, val_loader, train_sampler


def build_model_and_optimizer(args, num_classes, device, distributed):
    model = RVMForSemanticSegmentation(
        args.variant,
        num_classes=num_classes,
        pretrained_backbone=args.pretrained_backbone and args.rvm_checkpoint is None and args.resume is None,
    ).to(device)

    if args.rvm_checkpoint is not None and args.resume is None:
        checkpoint = torch_load(args.rvm_checkpoint, map_location="cpu")
        report = load_compatible_weights(model, checkpoint)
        print(
            f"Loaded {report['loaded']} tensors from RVM checkpoint; "
            f"skipped {len(report['skipped'])} incompatible tensors."
        )

    if args.sync_bn and distributed:
        model = torch.nn.SyncBatchNorm.convert_sync_batchnorm(model)

    optimizer = AdamW(
        [
            {"params": model.backbone.parameters(), "lr": args.backbone_learning_rate},
            {
                "params": list(model.aspp.parameters())
                + list(model.decoder.parameters())
                + list(model.project_seg.parameters()),
                "lr": args.learning_rate,
            },
        ],
        weight_decay=args.weight_decay,
    )
    scheduler = LambdaLR(
        optimizer,
        lr_lambda=lambda epoch: max(0.0, 1.0 - epoch / max(args.epochs, 1)) ** 0.9,
    )
    scaler = torch.cuda.amp.GradScaler(enabled=args.amp and device.type == "cuda")
    return model, optimizer, scheduler, scaler


def load_resume(path, model, optimizer, scheduler, scaler, class_names):
    checkpoint = torch_load(path, map_location="cpu")
    checkpoint_names = checkpoint.get("class_names")
    if checkpoint_names is not None and checkpoint_names != class_names:
        raise ValueError(
            f"Checkpoint classes {checkpoint_names} do not match requested {class_names}."
        )
    model.load_state_dict(checkpoint["model"], strict=True)
    if "optimizer" in checkpoint:
        optimizer.load_state_dict(checkpoint["optimizer"])
    if "scheduler" in checkpoint:
        scheduler.load_state_dict(checkpoint["scheduler"])
    if "scaler" in checkpoint:
        scaler.load_state_dict(checkpoint["scaler"])
    return int(checkpoint.get("epoch", -1)) + 1, float(checkpoint.get("best_miou", -1.0))


def amp_context(enabled):
    return torch.cuda.amp.autocast(enabled=enabled) if torch.cuda.is_available() else nullcontext()


def train_one_epoch(
    model, loader, optimizer, scaler, device, epoch, args, class_weights, rank
):
    model.train()
    running_loss = 0.0
    seen = 0
    progress = tqdm(loader, dynamic_ncols=True, disable=rank != 0, desc=f"Train {epoch:03d}")
    for step, (images, masks) in enumerate(progress):
        images = images.to(device, non_blocking=True)
        masks = masks.to(device, non_blocking=True)
        optimizer.zero_grad(set_to_none=True)
        with amp_context(args.amp and device.type == "cuda"):
            logits = model(images)[0]
            losses = semantic_loss(
                logits,
                masks,
                num_classes=len(class_weights) if class_weights is not None else logits.shape[1],
                class_weights=class_weights,
                ignore_index=args.ignore_index,
                ce_weight=args.ce_weight,
                dice_weight=args.dice_weight,
            )
        scaler.scale(losses["total"]).backward()
        scaler.step(optimizer)
        scaler.update()

        batch_size = images.shape[0]
        running_loss += losses["total"].detach().item() * batch_size
        seen += batch_size
        if rank == 0 and (step + 1) % args.print_every == 0:
            progress.set_postfix(loss=f"{running_loss / max(seen, 1):.4f}")

    totals = torch.tensor([running_loss, seen], dtype=torch.float64, device=device)
    if dist.is_available() and dist.is_initialized():
        dist.all_reduce(totals)
    return float(totals[0] / totals[1].clamp_min(1))


@torch.no_grad()
def validate(model, loader, device, args, class_names, class_weights, rank):
    model.eval()
    matrix = ConfusionMatrix(len(class_names), device=device)
    total_loss = 0.0
    seen = 0
    progress = tqdm(loader, dynamic_ncols=True, disable=rank != 0, desc="Validate")
    for images, masks in progress:
        images = images.to(device, non_blocking=True)
        masks = masks.to(device, non_blocking=True)
        with amp_context(args.amp and device.type == "cuda"):
            logits = model(images)[0]
            losses = semantic_loss(
                logits,
                masks,
                num_classes=len(class_names),
                class_weights=class_weights,
                ignore_index=args.ignore_index,
                ce_weight=args.ce_weight,
                dice_weight=args.dice_weight,
            )
        prediction = logits.argmax(dim=1)
        matrix.update(masks, prediction, ignore_index=args.ignore_index)
        batch_size = images.shape[0]
        total_loss += losses["total"].item() * batch_size
        seen += batch_size

    loss_totals = torch.tensor([total_loss, seen], dtype=torch.float64, device=device)
    if dist.is_available() and dist.is_initialized():
        dist.all_reduce(loss_totals)
    matrix.synchronize()
    metrics = matrix.compute(class_names)
    metrics["loss"] = float(loss_totals[0] / loss_totals[1].clamp_min(1))
    return metrics


def checkpoint_payload(
    model, optimizer, scheduler, scaler, epoch, best_miou, args, class_names
):
    serialized_args = {
        key: str(value) if isinstance(value, Path) else value
        for key, value in vars(args).items()
    }
    return {
        "model": unwrap_model(model).state_dict(),
        "optimizer": optimizer.state_dict(),
        "scheduler": scheduler.state_dict(),
        "scaler": scaler.state_dict(),
        "epoch": epoch,
        "best_miou": best_miou,
        "variant": args.variant,
        "num_classes": len(class_names),
        "class_names": class_names,
        "input_size": args.input_size,
        "args": serialized_args,
    }


def main():
    args = parse_args()
    class_names = parse_class_names(args.class_names)
    distributed, rank, world_size, local_rank, device = distributed_info(args)
    seed_everything(args.seed, rank)
    class_weights = parse_class_weights(args.class_weights, len(class_names))
    if class_weights is not None:
        class_weights = class_weights.to(device)

    if rank == 0:
        args.output_dir.mkdir(parents=True, exist_ok=True)
        print(f"Classes: {dict(enumerate(class_names))}")
        print(f"Input resolution: {args.input_size} x {args.input_size}")
        print(f"Validation resize mode: {args.val_resize_mode}")
        print(f"Device: {device}; world size: {world_size}")

    train_loader, val_loader, train_sampler = make_dataloaders(
        args, len(class_names), distributed, rank, world_size
    )
    if rank == 0:
        print(f"Training samples: {len(train_loader.dataset)}")
        print(f"Validation samples: {len(val_loader.dataset)}")

    model, optimizer, scheduler, scaler = build_model_and_optimizer(
        args, len(class_names), device, distributed
    )
    start_epoch, best_miou = 0, -1.0
    if args.resume:
        start_epoch, best_miou = load_resume(
            args.resume, model, optimizer, scheduler, scaler, class_names
        )
        if rank == 0:
            print(f"Resumed from epoch {start_epoch}; best mIoU={best_miou:.4f}")

    if distributed:
        model = DistributedDataParallel(
            model,
            device_ids=[local_rank] if device.type == "cuda" else None,
            broadcast_buffers=False,
        )

    if args.evaluate_only:
        metrics = validate(
            model, val_loader, device, args, class_names, class_weights, rank
        )
        if rank == 0:
            print(format_metrics(metrics))
            print(json.dumps(metrics, indent=2))
        if distributed:
            dist.destroy_process_group()
        return

    for epoch in range(start_epoch, args.epochs):
        if train_sampler is not None:
            train_sampler.set_epoch(epoch)
        started = time.time()
        train_loss = train_one_epoch(
            model, train_loader, optimizer, scaler, device, epoch, args, class_weights, rank
        )
        metrics = validate(
            model, val_loader, device, args, class_names, class_weights, rank
        )
        scheduler.step()

        if rank == 0:
            elapsed = time.time() - started
            print(
                f"Epoch {epoch:03d}: train_loss={train_loss:.4f}, "
                f"{format_metrics(metrics)}, time={elapsed:.1f}s"
            )
            metrics_row = {
                "epoch": epoch,
                "train_loss": train_loss,
                "learning_rate": optimizer.param_groups[-1]["lr"],
                **metrics,
            }
            append_metrics_csv(args.output_dir / "metrics.csv", metrics_row)

            improved = metrics["miou"] > best_miou
            if improved:
                best_miou = metrics["miou"]
            payload = checkpoint_payload(
                model, optimizer, scheduler, scaler, epoch, best_miou, args, class_names
            )
            atomic_torch_save(payload, args.output_dir / "last.pth")
            if improved:
                atomic_torch_save(payload, args.output_dir / "best_miou.pth")
            if (epoch + 1) % args.save_every == 0:
                atomic_torch_save(payload, args.output_dir / f"epoch_{epoch:03d}.pth")

    if distributed:
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
