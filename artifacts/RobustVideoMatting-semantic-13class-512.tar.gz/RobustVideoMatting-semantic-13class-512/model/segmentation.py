from typing import Dict, Optional

import torch
from torch import Tensor, nn
from torch.nn import functional as F

from .decoder import Projection, RecurrentDecoder
from .lraspp import LRASPP
from .mobilenetv3 import MobileNetV3LargeEncoder
from .resnet import ResNet50Encoder


class RVMForSemanticSegmentation(nn.Module):
    """
    RVM encoder + LR-ASPP + recurrent decoder adapted for multi-class logits.

    It accepts either images [B, C, H, W] or frame sequences [B, T, C, H, W].
    Recurrent states are useful for video inference and can be omitted for
    independent training images.
    """

    def __init__(
        self,
        variant: str = "mobilenetv3",
        num_classes: int = 13,
        pretrained_backbone: bool = False,
    ):
        super().__init__()
        if variant not in ("mobilenetv3", "resnet50"):
            raise ValueError(f"Unsupported variant: {variant}")
        if num_classes < 2:
            raise ValueError("num_classes must be at least 2")

        self.variant = variant
        self.num_classes = num_classes
        if variant == "mobilenetv3":
            self.backbone = MobileNetV3LargeEncoder(pretrained_backbone)
            self.aspp = LRASPP(960, 128)
            self.decoder = RecurrentDecoder([16, 24, 40, 128], [80, 40, 32, 16])
        else:
            self.backbone = ResNet50Encoder(pretrained_backbone)
            self.aspp = LRASPP(2048, 256)
            self.decoder = RecurrentDecoder([64, 256, 512, 256], [128, 64, 32, 16])

        self.project_seg = Projection(16, num_classes)

    def forward(
        self,
        src: Tensor,
        r1: Optional[Tensor] = None,
        r2: Optional[Tensor] = None,
        r3: Optional[Tensor] = None,
        r4: Optional[Tensor] = None,
        downsample_ratio: float = 1.0,
    ):
        if not 0 < downsample_ratio <= 1:
            raise ValueError("downsample_ratio must be in (0, 1].")
        src_sm = (
            self._interpolate(src, scale_factor=downsample_ratio)
            if downsample_ratio != 1
            else src
        )
        f1, f2, f3, f4 = self.backbone(src_sm)
        f4 = self.aspp(f4)
        hidden, *rec = self.decoder(src_sm, f1, f2, f3, f4, r1, r2, r3, r4)
        logits = self.project_seg(hidden)

        if logits.shape[-2:] != src.shape[-2:]:
            logits = self._interpolate(logits, size=src.shape[-2:])
        return [logits, *rec]

    @staticmethod
    def _interpolate(
        tensor: Tensor,
        scale_factor: Optional[float] = None,
        size=None,
    ):
        kwargs = {
            "size": size,
            "scale_factor": scale_factor,
            "mode": "bilinear",
            "align_corners": False,
        }
        if scale_factor is not None:
            kwargs["recompute_scale_factor"] = False
        if tensor.ndim == 5:
            batch, time = tensor.shape[:2]
            tensor = F.interpolate(tensor.flatten(0, 1), **kwargs)
            return tensor.unflatten(0, (batch, time))
        return F.interpolate(tensor, **kwargs)


def extract_state_dict(checkpoint) -> Dict[str, Tensor]:
    if isinstance(checkpoint, dict):
        for key in ("model", "state_dict", "model_state_dict"):
            if key in checkpoint and isinstance(checkpoint[key], dict):
                checkpoint = checkpoint[key]
                break
    if not isinstance(checkpoint, dict):
        raise TypeError("Checkpoint must contain a PyTorch state_dict.")
    return {
        (key[7:] if key.startswith("module.") else key): value
        for key, value in checkpoint.items()
        if isinstance(value, Tensor)
    }


def load_compatible_weights(model: nn.Module, checkpoint) -> Dict[str, object]:
    """Load matching RVM/segmentation weights and skip incompatible heads."""
    source = extract_state_dict(checkpoint)
    target = model.state_dict()
    compatible = {
        key: value
        for key, value in source.items()
        if key in target and target[key].shape == value.shape
    }
    skipped = sorted(
        key for key, value in source.items()
        if key not in target or target[key].shape != value.shape
    )
    result = model.load_state_dict(compatible, strict=False)
    return {
        "loaded": len(compatible),
        "skipped": skipped,
        "missing": list(result.missing_keys),
        "unexpected": list(result.unexpected_keys),
    }
