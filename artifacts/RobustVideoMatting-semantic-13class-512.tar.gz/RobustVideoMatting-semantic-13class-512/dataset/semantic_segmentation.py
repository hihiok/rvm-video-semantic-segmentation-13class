import random
from pathlib import Path
from typing import List, Tuple

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms
from torchvision.transforms import functional as F


IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}
MASK_EXTENSIONS = (".png", ".bmp", ".tif", ".tiff")


def _list_images(directory: Path) -> List[Path]:
    return sorted(
        path for path in directory.rglob("*")
        if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS
    )


def _find_mask(mask_dir: Path, relative_image: Path) -> Path:
    same_path = mask_dir / relative_image
    if same_path.is_file():
        return same_path

    stem_path = same_path.with_suffix("")
    matches = [stem_path.with_suffix(ext) for ext in MASK_EXTENSIONS]
    matches = [path for path in matches if path.is_file()]
    if len(matches) == 1:
        return matches[0]
    if not matches:
        raise FileNotFoundError(
            "No mask found for image "
            f"'{relative_image}'. Expected the same relative path/stem under '{mask_dir}'."
        )
    raise RuntimeError(f"Multiple masks found for '{relative_image}': {matches}")


def build_image_mask_pairs(image_dir: str, mask_dir: str) -> List[Tuple[Path, Path]]:
    image_dir = Path(image_dir).expanduser().resolve()
    mask_dir = Path(mask_dir).expanduser().resolve()
    if not image_dir.is_dir():
        raise FileNotFoundError(f"Image directory does not exist: {image_dir}")
    if not mask_dir.is_dir():
        raise FileNotFoundError(f"Annotation directory does not exist: {mask_dir}")

    images = _list_images(image_dir)
    if not images:
        raise RuntimeError(f"No supported images found under: {image_dir}")

    pairs = []
    for image_path in images:
        relative_image = image_path.relative_to(image_dir)
        pairs.append((image_path, _find_mask(mask_dir, relative_image)))
    return pairs


def letterbox_geometry(width: int, height: int, size: int):
    """Return resized (width, height) and centered padding for a square canvas."""
    if width <= 0 or height <= 0 or size <= 0:
        raise ValueError(
            f"width, height and size must be positive, got {width}, {height}, {size}"
        )
    scale = min(size / width, size / height)
    resized_w = max(1, min(size, int(round(width * scale))))
    resized_h = max(1, min(size, int(round(height * scale))))
    pad_left = (size - resized_w) // 2
    pad_top = (size - resized_h) // 2
    pad_right = size - resized_w - pad_left
    pad_bottom = size - resized_h - pad_top
    return resized_w, resized_h, (pad_left, pad_top, pad_right, pad_bottom)


class SemanticTrainTransform:
    """Joint image/mask augmentation with an exact square output size."""

    def __init__(
        self,
        size: int = 512,
        scale_range: Tuple[float, float] = (0.5, 2.0),
        hflip_probability: float = 0.5,
        ignore_index: int = 255,
    ):
        self.size = size
        self.scale_range = scale_range
        self.hflip_probability = hflip_probability
        self.ignore_index = ignore_index
        self.color_jitter = transforms.ColorJitter(
            brightness=0.2, contrast=0.2, saturation=0.2, hue=0.05
        )

    def __call__(self, image: Image.Image, mask: Image.Image):
        scale = random.uniform(*self.scale_range)
        source_w, source_h = image.size
        short_side = max(1, int(min(source_h, source_w) * scale))
        resize_scale = short_side / min(source_h, source_w)
        new_h = max(1, int(round(source_h * resize_scale)))
        new_w = max(1, int(round(source_w * resize_scale)))

        image = F.resize(
            image, [new_h, new_w], interpolation=F.InterpolationMode.BILINEAR
        )
        mask = F.resize(
            mask, [new_h, new_w], interpolation=F.InterpolationMode.NEAREST
        )

        pad_right = max(0, self.size - new_w)
        pad_bottom = max(0, self.size - new_h)
        if pad_right or pad_bottom:
            image = F.pad(image, [0, 0, pad_right, pad_bottom], fill=0)
            mask = F.pad(
                mask, [0, 0, pad_right, pad_bottom], fill=self.ignore_index
            )

        top, left, height, width = transforms.RandomCrop.get_params(
            image, output_size=(self.size, self.size)
        )
        image = F.crop(image, top, left, height, width)
        mask = F.crop(mask, top, left, height, width)

        if random.random() < self.hflip_probability:
            image = F.hflip(image)
            mask = F.hflip(mask)

        image = self.color_jitter(image)
        image = F.to_tensor(image)
        mask = torch.from_numpy(np.array(mask, dtype=np.int64, copy=True))
        return image, mask


class SemanticValidTransform:
    """Deterministic square transform for validation and testing."""

    def __init__(
        self,
        size: int = 512,
        resize_mode: str = "letterbox",
        ignore_index: int = 255,
    ):
        if resize_mode not in ("letterbox", "stretch"):
            raise ValueError("resize_mode must be 'letterbox' or 'stretch'")
        self.size = size
        self.resize_mode = resize_mode
        self.ignore_index = ignore_index

    def __call__(self, image: Image.Image, mask: Image.Image):
        if self.resize_mode == "stretch":
            image = F.resize(
                image,
                [self.size, self.size],
                interpolation=F.InterpolationMode.BILINEAR,
            )
            mask = F.resize(
                mask,
                [self.size, self.size],
                interpolation=F.InterpolationMode.NEAREST,
            )
        else:
            resized_w, resized_h, padding = letterbox_geometry(
                image.width, image.height, self.size
            )
            image = F.resize(
                image,
                [resized_h, resized_w],
                interpolation=F.InterpolationMode.BILINEAR,
            )
            mask = F.resize(
                mask,
                [resized_h, resized_w],
                interpolation=F.InterpolationMode.NEAREST,
            )
            image = F.pad(image, list(padding), fill=0)
            mask = F.pad(mask, list(padding), fill=self.ignore_index)
        image = F.to_tensor(image)
        mask = torch.from_numpy(np.array(mask, dtype=np.int64, copy=True))
        return image, mask


class SemanticSegmentationDataset(Dataset):
    """
    Loads RGB images and single-channel class-index masks.

    Masks are never converted with ``ToTensor`` because that would scale class
    IDs to [0, 1]. They remain integer ``torch.long`` tensors for CrossEntropy.
    """

    def __init__(
        self,
        image_dir: str,
        mask_dir: str,
        num_classes: int,
        transform=None,
        ignore_index: int = 255,
    ):
        self.pairs = build_image_mask_pairs(image_dir, mask_dir)
        self.num_classes = num_classes
        self.transform = transform
        self.ignore_index = ignore_index

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, index):
        image_path, mask_path = self.pairs[index]
        with Image.open(image_path) as image_file:
            image = image_file.convert("RGB")
        with Image.open(mask_path) as mask_file:
            if mask_file.mode not in ("L", "P", "I", "I;16"):
                raise ValueError(
                    f"Mask must be a one-channel class-index image, got mode "
                    f"'{mask_file.mode}' for: {mask_path}"
                )
            mask = mask_file.copy()

        if image.size != mask.size:
            raise ValueError(
                f"Image/mask size mismatch for '{image_path}' and '{mask_path}': "
                f"image={image.size}, mask={mask.size}. Masks must align with images."
            )

        raw_mask = torch.from_numpy(np.array(mask, dtype=np.int64, copy=True))
        self._validate_mask(raw_mask, mask_path)

        if self.transform is not None:
            image, mask = self.transform(image, mask)
        else:
            image = F.to_tensor(image)
            mask = raw_mask

        self._validate_mask(mask, mask_path)
        return image, mask

    def _validate_mask(self, mask, mask_path):
        valid = mask.ne(self.ignore_index)
        if valid.any():
            minimum = int(mask[valid].min())
            maximum = int(mask[valid].max())
            if minimum < 0 or maximum >= self.num_classes:
                values = torch.unique(mask[valid]).tolist()
                raise ValueError(
                    f"Mask '{mask_path}' contains class IDs {values}; expected "
                    f"0..{self.num_classes - 1} or ignore_index={self.ignore_index}."
                )
