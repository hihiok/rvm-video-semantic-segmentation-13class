#!/usr/bin/env bash
set -euo pipefail

CONDA_SH="${CONDA_SH:-/home/z00919662/anaconda3/etc/profile.d/conda.sh}"
CONDA_ENV_NAME="${CONDA_ENV_NAME:-ultraface}"
REPO_ROOT="${REPO_ROOT:-/data/pub1/z00919662/segmentation/RobustVideoMatting-semantic-13class-512}"
DATA_ROOT="${DATA_ROOT:-/data/pub1/y00841348/dataset/AI-Seg-12class/cocostuff164k+ade20k_13class}"
CHECKPOINT="${CHECKPOINT:-$REPO_ROOT/output/rvm_semantic_13class_512_2gpu/best_miou.pth}"

TEST_IMAGES="${TEST_IMAGES:-images/test}"
TEST_ANNOTATIONS="${TEST_ANNOTATIONS:-annotations/test}"
RESIZE_MODE="${RESIZE_MODE:-letterbox}"

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export PYTHONUNBUFFERED=1

[[ -f "$CONDA_SH" ]] || { echo "Conda initialization script not found: $CONDA_SH" >&2; exit 1; }
[[ -d "$REPO_ROOT" ]] || { echo "13-class repository not found: $REPO_ROOT" >&2; exit 1; }
[[ -f "$CHECKPOINT" ]] || { echo "Checkpoint not found: $CHECKPOINT" >&2; exit 1; }
[[ -d "$DATA_ROOT/$TEST_IMAGES" ]] || { echo "Test images not found: $DATA_ROOT/$TEST_IMAGES" >&2; exit 1; }
[[ -d "$DATA_ROOT/$TEST_ANNOTATIONS" ]] || { echo "Test masks not found: $DATA_ROOT/$TEST_ANNOTATIONS" >&2; exit 1; }

source "$CONDA_SH"
conda activate "$CONDA_ENV_NAME"
cd "$REPO_ROOT"

python test_semantic.py \
  --data-root "$DATA_ROOT" \
  --checkpoint "$CHECKPOINT" \
  --images "$TEST_IMAGES" \
  --annotations "$TEST_ANNOTATIONS" \
  --resize-mode "$RESIZE_MODE" \
  --batch-size 8 \
  --workers 8 \
  --amp

# 默认 letterbox：等比例缩放并补边，不造成形变。
# 如需复现旧的直接拉伸测试：
# RESIZE_MODE=stretch bash run_test_13class.sh
