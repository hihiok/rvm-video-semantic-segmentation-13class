#!/usr/bin/env bash
set -euo pipefail

# 可在运行前通过同名环境变量覆盖这些默认配置。
CONDA_SH="${CONDA_SH:-/home/z00919662/anaconda3/etc/profile.d/conda.sh}"
CONDA_ENV_NAME="${CONDA_ENV_NAME:-ultraface}"
REPO_ROOT="${REPO_ROOT:-/data/pub1/z00919662/segmentation/RobustVideoMatting-semantic-13class-512}"
DATA_ROOT="${DATA_ROOT:-/data/pub1/y00841348/dataset/AI-Seg-12class/cocostuff164k+ade20k_13class}"
OUTPUT_DIR="${OUTPUT_DIR:-$REPO_ROOT/output/rvm_semantic_13class_512_2gpu}"

TRAIN_IMAGES="${TRAIN_IMAGES:-images/train}"
TRAIN_ANNOTATIONS="${TRAIN_ANNOTATIONS:-annotations/train}"
VAL_IMAGES="${VAL_IMAGES:-images/val}"
VAL_ANNOTATIONS="${VAL_ANNOTATIONS:-annotations/val}"

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-4}"
export PYTHONUNBUFFERED=1

[[ -f "$CONDA_SH" ]] || { echo "Conda initialization script not found: $CONDA_SH" >&2; exit 1; }
[[ -d "$REPO_ROOT" ]] || { echo "13-class repository not found: $REPO_ROOT" >&2; exit 1; }
[[ -d "$DATA_ROOT/$TRAIN_IMAGES" ]] || { echo "Training images not found: $DATA_ROOT/$TRAIN_IMAGES" >&2; exit 1; }
[[ -d "$DATA_ROOT/$TRAIN_ANNOTATIONS" ]] || { echo "Training masks not found: $DATA_ROOT/$TRAIN_ANNOTATIONS" >&2; exit 1; }
[[ -d "$DATA_ROOT/$VAL_IMAGES" ]] || { echo "Validation images not found: $DATA_ROOT/$VAL_IMAGES" >&2; exit 1; }
[[ -d "$DATA_ROOT/$VAL_ANNOTATIONS" ]] || { echo "Validation masks not found: $DATA_ROOT/$VAL_ANNOTATIONS" >&2; exit 1; }

source "$CONDA_SH"
conda activate "$CONDA_ENV_NAME"
cd "$REPO_ROOT"

GPU_COUNT="$(python -c 'import torch; print(torch.cuda.device_count())')"
if [[ "$GPU_COUNT" -ne 2 ]]; then
  echo "Expected 2 visible GPUs, but PyTorch detected $GPU_COUNT. CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES" >&2
  exit 1
fi

mkdir -p "$OUTPUT_DIR"

# 默认自动从 last.pth 断点续训；不存在时从头训练。
RESUME_ARGS=()
if [[ -f "$OUTPUT_DIR/last.pth" ]]; then
  echo "Resuming from $OUTPUT_DIR/last.pth"
  RESUME_ARGS=(--resume "$OUTPUT_DIR/last.pth")
else
  echo "Starting a new 13-class training run"
fi

python -m torch.distributed.run \
  --standalone \
  --nnodes=1 \
  --nproc_per_node=2 \
  train_semantic.py \
  --data-root "$DATA_ROOT" \
  --train-images "$TRAIN_IMAGES" \
  --train-annotations "$TRAIN_ANNOTATIONS" \
  --val-images "$VAL_IMAGES" \
  --val-annotations "$VAL_ANNOTATIONS" \
  --variant mobilenetv3 \
  --class-names background,sky,person,plant,building,flower,food,water,desert,ice_or_snow,text,ball,mountain \
  --ignore-index 255 \
  --input-size 512 \
  --epochs 100 \
  --batch-size 8 \
  --workers 8 \
  --learning-rate 1e-4 \
  --backbone-learning-rate 1e-5 \
  --weight-decay 1e-4 \
  --ce-weight 1.0 \
  --dice-weight 1.0 \
  --train-scale-min 0.5 \
  --train-scale-max 2.0 \
  --val-resize-mode letterbox \
  --amp \
  --sync-bn \
  --save-every 10 \
  --print-every 20 \
  --output-dir "$OUTPUT_DIR" \
  "${RESUME_ARGS[@]}"
