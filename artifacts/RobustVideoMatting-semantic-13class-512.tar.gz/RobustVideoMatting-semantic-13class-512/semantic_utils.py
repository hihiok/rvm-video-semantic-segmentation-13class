import csv
import os
import random
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import torch
from torch import Tensor, distributed as dist
from torch.nn import functional as F


DEFAULT_CLASS_NAMES = [
    "background",
    "sky",
    "person",
    "plant",
    "building",
    "flower",
    "food",
    "water",
    "desert",
    "ice_or_snow",
    "text",
    "ball",
    "mountain",
]
DEFAULT_PALETTE = [
    (0, 0, 0),
    (70, 130, 180),
    (220, 20, 60),
    (34, 139, 34),
    (190, 190, 190),
    (255, 105, 180),
    (255, 165, 0),
    (0, 191, 255),
    (210, 180, 140),
    (224, 255, 255),
    (255, 215, 0),
    (148, 0, 211),
    (139, 69, 19),
]


def seed_everything(seed: int, rank: int = 0):
    seed = seed + rank
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def seed_worker(worker_id: int):
    worker_seed = torch.initial_seed() % (2 ** 32)
    np.random.seed(worker_seed)
    random.seed(worker_seed)


def parse_class_names(value: str) -> List[str]:
    names = [item.strip() for item in value.split(",") if item.strip()]
    if len(names) < 2:
        raise ValueError("--class-names must contain at least two comma-separated names.")
    if len(set(names)) != len(names):
        raise ValueError(f"Class names must be unique: {names}")
    return names


def parse_class_weights(value: Optional[str], num_classes: int):
    if value is None:
        return None
    weights = [float(item.strip()) for item in value.split(",")]
    if len(weights) != num_classes:
        raise ValueError(
            f"Expected {num_classes} class weights, received {len(weights)}."
        )
    return torch.tensor(weights, dtype=torch.float32)


def multiclass_dice_loss(
    logits: Tensor,
    target: Tensor,
    num_classes: int,
    ignore_index: int = 255,
    include_background: bool = True,
    epsilon: float = 1e-6,
):
    valid = target.ne(ignore_index)
    safe_target = target.masked_fill(~valid, 0)
    probabilities = logits.softmax(dim=1)
    one_hot = F.one_hot(safe_target, num_classes=num_classes)
    one_hot = one_hot.permute(0, 3, 1, 2).to(probabilities.dtype)
    valid = valid.unsqueeze(1)
    probabilities = probabilities * valid
    one_hot = one_hot * valid

    dims = (0, 2, 3)
    intersection = (probabilities * one_hot).sum(dims)
    denominator = probabilities.sum(dims) + one_hot.sum(dims)
    dice = (2 * intersection + epsilon) / (denominator + epsilon)
    if not include_background:
        dice = dice[1:]
    return 1 - dice.mean()


def semantic_loss(
    logits: Tensor,
    target: Tensor,
    num_classes: int,
    class_weights: Optional[Tensor] = None,
    ignore_index: int = 255,
    ce_weight: float = 1.0,
    dice_weight: float = 1.0,
):
    ce = F.cross_entropy(
        logits, target, weight=class_weights, ignore_index=ignore_index
    )
    dice = multiclass_dice_loss(
        logits, target, num_classes=num_classes, ignore_index=ignore_index
    )
    total = ce_weight * ce + dice_weight * dice
    return {"total": total, "cross_entropy": ce, "dice": dice}


class ConfusionMatrix:
    def __init__(self, num_classes: int, device):
        self.num_classes = num_classes
        self.matrix = torch.zeros(
            (num_classes, num_classes), dtype=torch.float64, device=device
        )

    @torch.no_grad()
    def update(self, target: Tensor, prediction: Tensor, ignore_index: int = 255):
        target = target.reshape(-1)
        prediction = prediction.reshape(-1)
        valid = (
            target.ne(ignore_index)
            & target.ge(0)
            & target.lt(self.num_classes)
        )
        indices = self.num_classes * target[valid] + prediction[valid]
        counts = torch.bincount(
            indices, minlength=self.num_classes ** 2
        ).reshape(self.num_classes, self.num_classes)
        self.matrix += counts

    def synchronize(self):
        if dist.is_available() and dist.is_initialized():
            dist.all_reduce(self.matrix, op=dist.ReduceOp.SUM)

    def compute(self, class_names: List[str]) -> Dict[str, object]:
        true_positive = self.matrix.diag()
        ground_truth = self.matrix.sum(dim=1)
        predicted = self.matrix.sum(dim=0)
        union = ground_truth + predicted - true_positive

        iou = true_positive / union.clamp_min(1)
        dice = 2 * true_positive / (ground_truth + predicted).clamp_min(1)
        valid_iou = union.gt(0)
        valid_dice = (ground_truth + predicted).gt(0)
        pixel_accuracy = true_positive.sum() / self.matrix.sum().clamp_min(1)

        return {
            "pixel_accuracy": float(pixel_accuracy),
            "miou": float(iou[valid_iou].mean()) if valid_iou.any() else 0.0,
            "mean_dice": float(dice[valid_dice].mean()) if valid_dice.any() else 0.0,
            "class_iou": {
                name: (float(iou[index]) if valid_iou[index] else None)
                for index, name in enumerate(class_names)
            },
            "class_dice": {
                name: (float(dice[index]) if valid_dice[index] else None)
                for index, name in enumerate(class_names)
            },
            "ground_truth_pixels": {
                name: int(ground_truth[index])
                for index, name in enumerate(class_names)
            },
        }


def unwrap_model(model):
    return model.module if hasattr(model, "module") else model


def atomic_torch_save(payload, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary)
    os.replace(temporary, path)


def torch_load(path, map_location="cpu"):
    """Use explicit legacy loading when supported by newer PyTorch versions."""
    try:
        return torch.load(path, map_location=map_location, weights_only=False)
    except TypeError:
        return torch.load(path, map_location=map_location)


def append_metrics_csv(path: Path, row: Dict[str, object]):
    path.parent.mkdir(parents=True, exist_ok=True)
    flat_row = {}
    for key, value in row.items():
        if isinstance(value, dict):
            for nested_key, nested_value in value.items():
                flat_row[f"{key}/{nested_key}"] = nested_value
        else:
            flat_row[key] = value
    write_header = not path.exists()
    with path.open("a", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=list(flat_row))
        if write_header:
            writer.writeheader()
        writer.writerow(flat_row)


def format_metrics(metrics: Dict[str, object]) -> str:
    class_iou = ", ".join(
        f"{name}={'N/A' if value is None else f'{value:.4f}'}"
        for name, value in metrics["class_iou"].items()
    )
    return (
        f"loss={metrics['loss']:.4f}, "
        f"mIoU={metrics['miou']:.4f}, "
        f"mDice={metrics['mean_dice']:.4f}, "
        f"pixel_acc={metrics['pixel_accuracy']:.4f}; "
        f"IoU: {class_iou}"
    )


def colorize_mask(mask: np.ndarray, palette=DEFAULT_PALETTE):
    if len(palette) < len(DEFAULT_CLASS_NAMES):
        raise ValueError(
            f"Palette has {len(palette)} colors, but "
            f"{len(DEFAULT_CLASS_NAMES)} classes are configured."
        )
    color = np.zeros((*mask.shape, 3), dtype=np.uint8)
    for index, rgb in enumerate(palette):
        color[mask == index] = rgb
    return color
