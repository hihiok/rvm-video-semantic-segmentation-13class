#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "$SCRIPT_DIR/.." && pwd)"
cd "$REPO_ROOT"

if [[ $# -lt 2 ]]; then
  echo "Usage: bash scripts/evaluate_semantic_512.sh DATA_ROOT CHECKPOINT [SPLIT]"
  exit 2
fi

SPLIT="${3:-test}"

python test_semantic.py \
  --data-root "$1" \
  --checkpoint "$2" \
  --images "images/$SPLIT" \
  --annotations "annotations/$SPLIT" \
  --resize-mode letterbox \
  --batch-size 8 \
  --workers 8
