# RVM 十三类别语义分割（512 × 512）

本工程把 RVM 的输出头改为 13 通道语义分割头，保留
MobileNetV3、LR-ASPP 与 recurrent decoder。

## 类别定义

| ID | 类别 |
|---:|---|
| 0 | background |
| 1 | sky |
| 2 | person |
| 3 | plant |
| 4 | building |
| 5 | flower |
| 6 | food |
| 7 | water |
| 8 | desert |
| 9 | ice_or_snow |
| 10 | text |
| 11 | ball |
| 12 | mountain |

原始 mask 应为单通道 class-index 图，像素值只需包含 `0–12`。
`255=ignore` 是可选值；即使原始 mask 没有 255，数据增强和
letterbox 仍会用 255 标记补边，避免 padding 被误算成 background。

## 推荐目录

```text
cocostuff164k+ade20k_13class/
├── images/
│   ├── train/
│   ├── val/
│   └── test/
└── annotations/
    ├── train/
    ├── val/
    └── test/
```

图片和 mask 必须保持相同的相对路径和 stem，扩展名可以不同。
若实际 split 名称不同，通过命令参数显式指定。

## 数据检查

```bash
python tools/check_semantic_dataset.py \
  --data-root /data/pub1/y00841348/dataset/AI-Seg-12class/cocostuff164k+ade20k_13class \
  --splits train val test
```

检查器会验证配对、尺寸、单通道格式、class ID、每类像素数、
每类图片数以及 background-only 图片数。任何 `13–254` 的类别 ID
都会报错。

## 单 GPU 训练

```bash
bash scripts/train_semantic_512.sh \
  /data/pub1/y00841348/dataset/AI-Seg-12class/cocostuff164k+ade20k_13class \
  output/rvm_semantic_13class_512 \
  train val
```

## 两 GPU DDP 训练

先选择两张空闲 GPU：

```bash
export CUDA_VISIBLE_DEVICES=2,3

bash scripts/train_semantic_13class_512_2gpu.sh \
  /data/pub1/y00841348/dataset/AI-Seg-12class/cocostuff164k+ade20k_13class \
  output/rvm_semantic_13class_512 \
  train val
```

如需加载原始 RVM、旧五类或旧十二类模型的兼容权重，可把 checkpoint 作为
第五个参数。非 13 类 head 形状不兼容，会自动跳过并随机初始化：

```bash
bash scripts/train_semantic_13class_512_2gpu.sh \
  /data/pub1/y00841348/dataset/AI-Seg-12class/cocostuff164k+ade20k_13class \
  output/rvm_semantic_13class_512 \
  train val \
  /path/to/rvm_or_old_semantic_checkpoint.pth
```

默认配置：

- 输入：512 × 512
- loss：Cross-Entropy + multiclass soft Dice
- optimizer：AdamW
- head/decoder/LR-ASPP LR：`1e-4`
- backbone LR：`1e-5`
- epoch：100
- batch size：每 GPU 8
- AMP：开启
- 两卡 DDP 时 SyncBatchNorm：开启
- 验证：保持宽高比的 letterbox，GT padding 为 255

训练图片互不相关，因此 `model(images)` 不传递 recurrent state。
网络仍包含 ConvGRU，但每个 batch 的 state 都从零开始。

## 恢复训练

```bash
export CUDA_VISIBLE_DEVICES=2,3

python -m torch.distributed.run \
  --standalone --nproc_per_node=2 \
  train_semantic.py \
  --data-root /data/pub1/y00841348/dataset/AI-Seg-12class/cocostuff164k+ade20k_13class \
  --train-images images/train \
  --train-annotations annotations/train \
  --val-images images/val \
  --val-annotations annotations/val \
  --resume output/rvm_semantic_13class_512/last.pth \
  --output-dir output/rvm_semantic_13class_512 \
  --sync-bn
```

## 测试

```bash
bash scripts/evaluate_semantic_512.sh \
  /data/pub1/y00841348/dataset/AI-Seg-12class/cocostuff164k+ade20k_13class \
  output/rvm_semantic_13class_512/best_miou.pth \
  test
```

默认 `--resize-mode letterbox`。如需和旧的直接拉伸口径对比，可使用：

```bash
python test_semantic.py \
  --data-root /data/pub1/y00841348/dataset/AI-Seg-12class/cocostuff164k+ade20k_13class \
  --images images/test \
  --annotations annotations/test \
  --checkpoint output/rvm_semantic_13class_512/best_miou.pth \
  --resize-mode stretch
```

## 图片推理

```bash
python inference_semantic.py \
  --checkpoint output/rvm_semantic_13class_512/best_miou.pth \
  --input /path/to/image_or_folder \
  --output-dir inference_output \
  --resize-mode letterbox
```

输出包括：

- `*_mask.png`：0–12 的单通道预测 mask
- `*_color.png`：彩色 mask
- `*_overlay.jpg`：叠加图、区域类别文字和颜色图例

默认不保留 recurrent state，适合互不相关的图片。只有使用连续视频帧
训练过模型后，才建议对有序帧显式添加 `--keep-recurrence`。
